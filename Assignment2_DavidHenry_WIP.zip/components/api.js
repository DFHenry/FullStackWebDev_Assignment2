import axios from "axios";

const url = "http://colormind.io/api";
const data = 
{
    model: "ui"
};

async function getColours()
{
    const response = await axios.post(url, data);
    const palette = response.data;
    //console.log(palette);

    return palette;

    //console.log(response.result);
    // let url = 'http://colormind.io/api/';

    // let data =
    // {
    //     model : "default"
    // };

    // var http = new XMLHttpRequest();

    // http.onreadystatechange = function ()
    // {
    //     if(http.readyState == 4 && http.status == 200)
    //     {
    //         var palette = JSON.parse(http.responseText).result;
    //     }
    // }

    // http.open("POST", url, true);
    // http.send(JSON.stringify(data));
}

export default
{
    getColours
};